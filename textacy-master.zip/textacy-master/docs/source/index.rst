
.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2

   getting_started/installation
   getting_started/quickstart
   api_reference
   changelog
   license
