---
name: documentation
about: You noticed a mistake or found something unclear in the docs.
labels: 'docs'
assignees: ''

---

### what's wrong?
<!-- Describe the problem or confusion here. If you've found a minor mistake and know how to fix it, feel free to skip this issue and submit a pull request instead: https://github.com/chartbeat-labs/textacy/pulls -->

### relevant page or section
<!-- Link to the URL and/or source of the problematic documentation. -->
